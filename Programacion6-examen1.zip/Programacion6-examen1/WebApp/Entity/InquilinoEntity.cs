﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class TipoInquilinoEntity
    {
        public int? Id_TipoInquilino { get; set; }
        public string Descripcion { get; set; }
        public Boolean Estado { get; set; }
    }
}
