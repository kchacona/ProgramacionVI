

 declare function reflectionIsSupported(): false | any;
 //declare function copyReflectionMetadata(to: VueConstructor, from: any): void;
