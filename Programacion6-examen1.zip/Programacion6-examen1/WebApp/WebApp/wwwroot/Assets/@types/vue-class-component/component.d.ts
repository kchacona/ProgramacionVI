

 declare const $internalHooks: string[];
 declare function componentFactory(Component: VueClass<Vue>, options?: ComponentOptions<Vue>): VueClass<Vue>;
