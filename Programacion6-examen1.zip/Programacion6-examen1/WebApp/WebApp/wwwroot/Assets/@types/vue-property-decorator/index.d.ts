﻿
declare var module: IModuleVueComponent;

declare var httpVueLoader: IhttpVueLoader;